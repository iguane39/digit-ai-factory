# Ouverture de session sous le délai du client : correctif + candidatures

À coller dans une session Claude Code ouverte à la racine de `digit-ai-factory`, **dans un terminal** (`claude`), pas dans le panneau de l'extension VS Code, qui échoue justement à l'ouverture.

Le zip est à décompresser à la racine du dépôt. Il dépose :
- `Digit-AI - Correctif Factory - Ouverture asynchrone et contexte JSON - 20261013b.patch`
- `input/01-candidatures/ouverture-de-session-sous-le-delai-du-client-20261013b.tf.jsonl`

## 1. Le correctif

### Pourquoi

Le CLI ne répond à l'initialisation qu'après la fin de tous les hooks `SessionStart` synchrones. L'extension VS Code abandonne au-delà de 60 s, avec le message « Subprocess initialization did not complete within 60000ms — check authentication and network connectivity ». `oracles/hook-ouverture.mjs` (avec `bootstrap --pull`, 240 s de délai) a dépassé ce seuil le 12/10.

Second défaut, trouvé en le prouvant : la sortie texte du hook fait 10 777 octets. Au-delà d'environ 10 Ko, le harnais la remplace par un aperçu de 2 Ko, si bien que la section « Gates actifs dans cette session (R-44) » n'atteint jamais l'assistant.

### Ce que change le correctif (4 fichiers)

- `oracles/hook-ouverture.mjs` : nouveau drapeau `--contexte-json`, qui émet `hookSpecificOutput.additionalContext` précédé d'un en-tête signalant l'asynchronie. Le texte brut reste le défaut.
- `.claude/settings.json` : le hook d'ouverture passe en `--contexte-json` et `"async": true`. `hook-produits-intacts --empreinte` reste synchrone : son relevé doit précéder tout geste.
- `gabarits/settings-produit.json` : même changement pour les produits.
- `oracles/hook-ouverture.test.mjs` : 2 cas ajoutés (JSON valide sur l'événement SessionStart ; contexte portant tout le relevé texte).

### Étapes

1. Vérifier que `HEAD` descend de `5ecdee3` et que les 4 fichiers n'ont pas bougé depuis. Sinon, s'arrêter et le signaler.
2. `git apply --check` puis `git apply` sur le `.patch`.
3. `node oracles/hook-ouverture.test.mjs` : attendu 9 PASS, 0 FAIL.
4. `node oracles/self-tests.mjs` : **non rejoué côté claude.ai** (interrompu). Le comparer à un passage sur `HEAD` sans le correctif ; seuls les défauts préexistants sont admis. Le 12/10, ils étaient 5 : `oracle-conformite-projet.mjs`, `oracle-run-reseau.mjs`, `todo/ingerer-r45.test.mjs`, `todo/self-test.mjs`, `oracle-gabarits-documents.mjs`. Ne committer de `oracles/baseline-recettes.json` que la ligne de `hook-ouverture.test.mjs`.
5. Mesurer sur le poste, depuis la racine :
   `Measure-Command { node oracles/hook-ouverture.mjs | Out-Null } | Select TotalMilliseconds`
6. Ouvrir une session dans l'extension VS Code et vérifier qu'elle démarre. Ensuite, demander à l'assistant, sans outil, s'il voit la section « Gates actifs dans cette session (R-44) ».
7. Committer, sans pousser sans accord de Sébastien.

### Hors périmètre, à dire à Sébastien

- Les produits existants portent une **copie** de `settings-produit.json` dans leur `.claude/settings.json`. Le gabarit corrigé ne les met pas à jour : la propagation suit l'héritage (geste humain, R-29).
- Le coût du palliatif : le relevé de fraîcheur peut arriver après le premier échange. La candidature n° 1 porte la vraie correction.

## 2. Les candidatures

Un sidecar, 2 candidatures, cible `pilot`, sans `classe` (candidature hors lot ; aucune clé du référentiel ne nomme ces défauts ; voisines citées dans le contenu) :

1. L'ouverture dépend d'un hook synchrone de durée non bornée, et le client abandonne à 60 s. Score 4×5/3.
2. La sortie texte d'un hook au-delà de 10 Ko est tronquée à 2 Ko, et les gates R-44 n'atteignent pas l'assistant. Score 4×5/2.

Ingestion :
`node todo/ingerer-lot.mjs "input/01-candidatures/ouverture-de-session-sous-le-delai-du-client-20261013b.tf.jsonl"`
puis `node todo/oracle-todo.mjs todo/TODO.jsonl todo/TODO-ARCHIVE.jsonl` (chemins **positionnels**).

Déjà rejoué sur registre jetable, avec des référentiels de noms vides : ingestion OK (empreinte `fe8cdb187a1a`), idempotence OK, `oracle-todo` PASS. **Les identifiants frappés au banc ne valent rien** : seule l'ingestion réelle les fixe. L'anonymisation réelle se joue sur le poste, avec les vrais référentiels.

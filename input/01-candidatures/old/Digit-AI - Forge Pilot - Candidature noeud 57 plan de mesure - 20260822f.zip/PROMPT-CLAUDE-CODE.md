# PROMPT-CLAUDE-CODE — dépôt et ingestion du lot « nœud 57, plan de mesure »

Colle ce fichier dans une session Claude Code ouverte à la racine du clone de
`iguane39/digit-ai-forge-pilot`. Ce lot **n'a jamais été poussé** : tout ce qui suit reste à faire.

## Ce que contient le lot

Une seule candidature, en un seul sidecar — donc **une seule commande d'ingestion** :

```
input/01-candidatures/candidature-noeud-57-plan-mesure.tf.jsonl
```

Elle cible `digit-ai-forge-seo-geo`. Elle exprime un besoin, des invariants et des critères
d'acceptation — **jamais la cible** : le choix de l'objet (texte de la grille, champ de
front-matter, généralisation du prédicat de terrain, contrôle dédié) reste un arbitrage de la forge.

## Ce qui a déjà été rejoué, et où

Sur un **registre scratch** (copie de `todo/TODO.jsonl` au HEAD `6aa0b20`), jamais sur le vrai :

| Contrôle | Commande | Résultat |
|---|---|---|
| Ingestion | `node todo/ingerer-lot.mjs <sidecar> --registre <scratch>` | 1 candidature, empreinte `5cb9ccbd581a` |
| Idempotence | même commande, 2ᵉ passe | `[DÉJÀ INGÉRÉ]`, 0 création |
| Intégrité | `node todo/oracle-todo.mjs <scratch> <archive>` | R1-R11 **PASS**, 9 actifs / 465 archivés |

L'id frappé au scratch était `TF-0474`. **Il n'est pas acquis** : l'ordre d'ingestion réel tranche,
et un id de scratch ne se note jamais. Ne le reporte nulle part.

## Étapes

1. `git pull` — le dépôt bouge plusieurs fois par jour, le lot a été préparé sur `6aa0b20`.
2. Copier le sidecar dans `input/01-candidatures/` (arborescence du zip identique à celle du dépôt).
3. **Avant d'ingérer, confronter au registre ET à l'archive.** L'anti-doublon a été exécuté à la
   rédaction (source : `todo/TODO.jsonl` + `todo/TODO-ARCHIVE.jsonl` au HEAD `6aa0b20` — 2 342 événements
   dont 472 créations, 0 occurrence sur perception / part de voix / paraphrase / réplication /
   échantillonnage), mais des lots concurrents ont pu entrer depuis.
4. `node todo/ingerer-lot.mjs input/01-candidatures/candidature-noeud-57-plan-mesure.tf.jsonl`
5. `node todo/oracle-todo.mjs todo/TODO.jsonl todo/TODO-ARCHIVE.jsonl`
   — **arguments positionnels** : un `--registre` passé ici est lu comme le chemin des actifs et
   rend un R8 faux.
6. Régénérer le README du dossier si le hook ne l'a pas fait (`scripts/readme-dossiers.mjs`).
7. Commit + push.

## Points à surveiller

- **La décision reste humaine.** L'ingestion met en `candidat` ; rien ne passe en `decide` sans
  mandat. Ne décide pas cet item dans la foulée.
- **Étude d'opportunité (TF-0155)** : cet item ne crée pas d'objet durable et ne touche qu'une
  forge, mais il porte un gain 4 avec preuve 5 — la condition « gain ≥ 3 avec preuve ≤ 2 » n'est
  pas remplie, donc l'étude n'est pas déclenchée par cette règle. À reconsidérer si l'arbitrage de
  la forge élargit le périmètre aux 13 nœuds de la classe signalée.
- **R-45 / R-46** ne s'appliquent pas ici : ce sont des exigences sur les lots `.md` de retours
  produits, pas sur les candidatures hors lot. Si `ingerer-lot.mjs` refuse pour cette raison, c'est
  un défaut à remonter, pas une section à ajouter au sidecar.

# Handoff — dépôt et ingestion du lot « frontmatter des skills » (22/08/2026)

Produit depuis claude.ai, qui ne peut pas pousser sur GitHub (aucun credential, pas de `gh`).
Le dépôt, l'ingestion et le push restent à faire ici.

## Ce que contient le lot

Un seul sidecar, une seule candidature, aucun `.md` homonyme :

```
input\01-candidatures\candidature-frontmatter-skills-20260822.tf.jsonl
```

Empreinte sha256 normalisée LF : **`d5d85f425d68`** (12 premiers caractères).

L'absence de `.md` homonyme est volontaire : R-45 et R-46 ne s'appliquent
qu'aux sidecars flanqués d'un `.md`, et une candidature hors lot n'a pas de lot,
donc rien à déclarer. Ne pas lui fabriquer un jumeau `.md`, cela la ferait
entrer dans le champ des deux règles sans qu'elle ait de section à porter.

## Ce qui a déjà été prouvé par exécution (sur registre scratch, 22/08)

| Contrôle | Commande rejouée | Résultat |
|---|---|---|
| Validation de schéma et ingestion | `ingerer-lot.mjs … --sans-fetch` | `[OK] 1 candidature(s) ingérée(s) en CANDIDAT`, exit 0 |
| Idempotence | même commande relancée | `[DÉJÀ INGÉRÉ] empreinte d5d85f425d68 — 0 création`, exit 0 |
| Intégrité du registre | `oracle-todo.mjs <actifs> <archive>` | `PASS` sur R1-R11, exit 0 |
| R-45 et R-46 | implicite à l'ingestion, qui refuse en rejet atomique | non déclenchées, sidecar sans `.md` |
| Projection en page (classe TF-0469) | `generer-page.mjs` puis `check_html.py` | `PASS` avant comme après, mêmes avertissements — la prose du `contenu` ne déclenche pas L12 |

L'id frappé sur le scratch était `TF-0472`. **Il n'est pas acquis** : le scratch
ne réserve rien, et plusieurs lots visent les mêmes numéros. L'ordre réel
d'ingestion tranchera.

## Pré-contrôles avant de déposer

1. **Indice de nommage.** Seul `20260822a` est consommé au dépôt, et par des
   séries produit (`Hoopiz`, `digit-ai-fr`, `Bibliotheque-Video-IA-Ceetrus`).
   Aucun livrable préfixé `Digit-AI` du 22/08 n'existe dans les dépôts.
   Vérifier qu'une session parallèle ne l'a pas consommé depuis, et renuméroter
   le zip le cas échéant.
2. **Empreinte déjà ingérée ?** Chercher `d5d85f425d68` dans `todo\TODO.jsonl`
   et `todo\TODO-ARCHIVE.jsonl` avant d'ingérer. Si elle y est, il n'y a rien à faire.
3. **Registre distant à jour.** Le préflight TF-0394 refuse l'ingestion si
   `origin/main` a avancé sur les fichiers du registre. Faire le `git pull --rebase`
   d'abord plutôt que d'assumer `--sans-fetch`.
4. **Lots en attente.** Six lots du 17/08 attendaient encore leur dépôt à la
   dernière trace connue, et le handoff du lot `i` demandait de concaténer cinq
   sidecars en une seule ingestion. Celui-ci est un lot de plus : décider s'il
   rejoint cette concaténation ou s'il s'ingère seul. Un fichier concaténé porte
   une empreinte neuve, donc l'idempotence ne protège plus contre une double
   ingestion — d'où le pré-contrôle 2 sur chaque empreinte d'origine.

## Commandes

```powershell
# depuis la racine du dépôt digit-ai-forge-pilot
git pull --rebase
copy "candidature-frontmatter-skills-20260822.tf.jsonl" "input\01-candidatures\"
node todo\ingerer-lot.mjs "input\01-candidatures\candidature-frontmatter-skills-20260822.tf.jsonl"
```

L'ingestion rejoue `oracle-todo` et régénère la vue toute seule quand elle vise
le registre par défaut. Si tu veux la rejouer à la main, **attention aux
arguments** : `oracle-todo.mjs` prend ses chemins en **positionnels**, alors que
`ingerer-lot.mjs` prend `--registre`. Un `--registre` passé à `oracle-todo` est
lu comme le chemin des actifs et rend un R8 en échec entièrement faux.

```powershell
node todo\oracle-todo.mjs todo\TODO.jsonl todo\TODO-ARCHIVE.jsonl
```

Puis déplacer le sidecar ingéré vers `input\01-candidatures\old\` et pousser.

## Ce que le lot ne demande pas

La candidature exprime un besoin, ses invariants et ses critères d'acceptation.
Elle ne désigne ni le skill à modifier, ni le dépôt d'accueil, ni la forme du
contrôle : cet arbitrage appartient à la forge, et la décision de passer l'item
de `candidat` à décidé appartient à l'humain.

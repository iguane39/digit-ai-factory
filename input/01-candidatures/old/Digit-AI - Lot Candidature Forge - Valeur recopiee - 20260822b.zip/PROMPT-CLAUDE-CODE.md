# Handoff — dépôt et ingestion de la candidature « valeur recopiée » (22/08/2026)

Session à ouvrir **dans le dossier du dépôt `digit-ai-forge-pilot`**, avec Claude Code.
Produit depuis claude.ai, où le push GitHub est impossible (aucun identifiant dans le conteneur).

## Ce que contient le lot

Un seul fichier, une seule commande d'ingestion :

- `input/01-candidatures/candidature-valeur-recopiee-20260822.tf.jsonl` — **1 candidature**

Candidature **hors lot** : pas de `.md` homonyme, donc **hors périmètre R-45 et R-46**
(les deux bornes ne s'appliquent qu'aux sidecars flanqués d'un `.md`).

## Ce qui a déjà été joué, et où

Tout ci-dessous a été exécuté sur une **copie** du dépôt clonée au commit `6aa0b20`,
jamais sur le dépôt réel.

| Contrôle | Résultat |
|---|---|
| `ingerer-lot.mjs` sur registre scratch | OK — 1 candidature en `candidat`, **empreinte de lot `a8ef4baee771`** |
| Idempotence (2ᵉ passage) | `[DÉJÀ INGÉRÉ]` — 0 création |
| `oracle-todo.mjs` | **PASS** — 9 actifs / 465 archivés, registre intègre |
| `todo/self-test.mjs` avec la candidature ingérée | **48 PASS, 0 FAIL** |
| Baseline sans la candidature | **48 PASS, 0 FAIL** — aucune régression introduite |
| Anti-doublon | 2 347 événements, 473 créations balayées (détail dans le champ `contenu`) |

Le pas de recette `check_html` exige `digit-ai-forge-agents/.claude/skills/digit-ai-page-html/scripts/check_html.py` ;
il a été rendu jouable en clonant `digit-ai-forge-agents` à côté. Sans ce clone, deux pas sortent
en FAIL « gate injouable » — ce n'est pas un défaut du lot.

**L'id TF attribué au scratch n'est pas noté ici** : un id obtenu sur registre scratch ne se note
jamais comme acquis. Seul l'ordre d'ingestion réel le tranche.

## Ce qu'il reste à faire

```bash
# 1. déposer le sidecar
cp candidature-valeur-recopiee-20260822.tf.jsonl input/01-candidatures/

# 2. ingérer (frappe l'id, met en candidat — la décision reste humaine)
node todo/ingerer-lot.mjs input/01-candidatures/candidature-valeur-recopiee-20260822.tf.jsonl

# 3. rejouer les gates
node todo/oracle-todo.mjs todo/TODO.jsonl todo/TODO-ARCHIVE.jsonl
node todo/self-test.mjs

# 4. régénérer les vues et le README du dossier, puis committer
node todo/generer-page.mjs
node scripts/readme-dossiers.mjs
git add -A && git commit -m "candidature : la loi 4 ne dit pas qu'une note ne doit pas recopier une valeur mobile"
git push
```

Après ingestion, déplacer le sidecar dans `input/01-candidatures/old/` conformément au rôle
du dossier (racine = à ingérer, ingéré → `old\`).

## Ce que le lot NE fait pas

- Il ne choisit pas la cible : règle de rédaction du socle, extension de `oracles/fraicheur-claims.json`,
  nouvel oracle, ou combinaison — l'arbitrage appartient à la forge.
- Il ne corrige aucune instance existante. Les documents déjà porteurs de la classe
  (README de forge-tests, manifeste forge-seo-geo) sont cités comme critère d'acceptation,
  pas patchés en passant.
- Il ne touche ni au registre, ni aux oracles, ni à aucun autre fichier du dépôt.
